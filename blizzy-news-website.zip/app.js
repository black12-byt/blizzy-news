const $ = (s) => document.querySelector(s);
const dateLabel = (value) => new Date(value + "T12:00:00").toLocaleDateString("en", {day:"numeric",month:"short",year:"numeric"});
const publishedArticles = ARTICLES.filter(a => a.published).sort((a,b) => b.date.localeCompare(a.date));
$("#today").textContent = new Date().toLocaleDateString("en", {weekday:"short",day:"numeric",month:"short",year:"numeric"});
$("#year").textContent = new Date().getFullYear();

const card = (a, featured=false) => `
  <article class="${featured ? "feature-card" : "story-card"}">
    <a href="article.html?id=${encodeURIComponent(a.id)}" aria-label="Read ${a.title}">
      <div class="${featured ? "feature-image" : "story-image"}">${featured ? "BLIZZY / NEWS" : "BN"}</div>
    </a>
    <div class="${featured ? "feature-content" : "story-content"}">
      <div class="meta"><span class="tag">${a.category}</span> &nbsp;•&nbsp; ${dateLabel(a.date)}</div>
      <h3><a href="article.html?id=${encodeURIComponent(a.id)}">${a.title}</a></h3>
      <p>${a.excerpt}</p>
      <a class="read-link" href="article.html?id=${encodeURIComponent(a.id)}">READ STORY →</a>
    </div>
  </article>`;

const featured = publishedArticles.slice(0,2);
$("#featured").innerHTML = featured.length ? featured.map(a => card(a,true)).join("") : '<p class="empty-state">No published stories yet.</p>';

const categories = ["All", ...new Set(publishedArticles.map(a => a.category))];
let activeCategory = "All";
function renderFilters(){
  $("#filters").innerHTML = categories.map(c => `<button class="filter ${c===activeCategory?"active":""}" data-filter="${c}">${c}</button>`).join("");
  document.querySelectorAll("[data-filter]").forEach(btn => btn.addEventListener("click", () => {activeCategory=btn.dataset.filter;renderFilters();renderStories();}));
}
function renderStories(){
  const term = $("#searchInput").value.trim().toLowerCase();
  const items = publishedArticles.filter(a => (activeCategory==="All" || a.category===activeCategory) && [a.title,a.excerpt,a.category,a.author].join(" ").toLowerCase().includes(term));
  $("#storyGrid").innerHTML = items.map(a => card(a)).join("");
  $("#emptyState").hidden = items.length !== 0;
}
renderFilters(); renderStories();
$("#searchInput").addEventListener("input", renderStories);
document.querySelectorAll("[data-category-link]").forEach(link => link.addEventListener("click", () => {
  activeCategory = link.dataset.categoryLink;
  if (!categories.includes(activeCategory)) activeCategory = "All";
  renderFilters(); renderStories();
}));
$("#menuToggle").addEventListener("click", () => {
  const nav = $("#mainNav"); const open = nav.classList.toggle("open");
  $("#menuToggle").setAttribute("aria-expanded", String(open));
});
