# BLIZZY NEWS

A responsive, static news website. It uses HTML, CSS and vanilla JavaScript, and can be hosted free with GitHub Pages.

## Files
- `index.html` — homepage
- `styles.css` — responsive design
- `articles.js` — **the file you edit to publish articles**
- `article.html` — individual article page
- `about.html`, `contact.html`, `privacy.html` — information pages
- `assets/favicon.svg` — browser icon

## Publish with GitHub Pages
1. Sign in to https://github.com or create an account.
2. Create a new **public** repository named `blizzy-news` (or another name you prefer).
3. Upload all files and the `assets` folder from this package to the repository's root. Do not upload the ZIP file itself.
4. In the repository, open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch **main** and folder **/(root)**, then press **Save**.
7. Wait a few minutes. Your site address will be `https://YOUR-USERNAME.github.io/blizzy-news/`.

If you name the repository exactly `YOUR-USERNAME.github.io`, GitHub Pages uses `https://YOUR-USERNAME.github.io/` instead.

## Publish a new article (no dashboard)
1. Open your GitHub repository.
2. Open `articles.js`, then tap the pencil **Edit** icon.
3. Add a new article object at the TOP inside the `ARTICLES` array, before the first `{`. Separate entries with commas.
4. Fill in a unique `id` using lowercase letters and hyphens. Example: `new-road-project-announced`.
5. Set `published: true`, then commit the changes.
6. GitHub Pages will update automatically after a short delay.

### Article template
Copy this object into `articles.js` inside the `ARTICLES` array:

```js
{
  id: "your-unique-article-name",
  title: "Your article headline",
  category: "General",
  date: "2026-11-25",
  author: "Blizzy News Desk",
  excerpt: "A short summary that appears on the homepage.",
  published: true,
  body: [
    "First paragraph of your article.",
    "Second paragraph of your article.",
    "Third paragraph of your article."
  ]
},
```

Use one of these categories or create your own: Politics, Technology, Business, Entertainment, Sports, General.

**Important:** Keep straight quotation marks around text, put commas between fields, and keep the comma after the article object if another article follows it. Do not put a comma after the final object in the array (the starter file already demonstrates the format).

## Add your own domain later
In the GitHub repository go to **Settings → Pages → Custom domain**, enter your domain, and follow GitHub's DNS instructions at your domain provider. Do not guess DNS records; use the exact records GitHub shows for your domain.

## Before launch
- Replace the sample articles with your own verified reporting.
- Replace the placeholder email on `contact.html`.
- Add your social media links if you want them.
- Use images you own or have permission to publish. This starter uses a designed graphic placeholder, not article photography.
