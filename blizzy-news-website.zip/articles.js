/*
  BLIZZY NEWS — ARTICLE PUBLISHING
  Add new stories to the top of this list. Keep the commas and quotation marks.
  Set published to true when the article is ready to appear on the website.
  Use date format YYYY-MM-DD. The body is an array of paragraphs.
*/
const ARTICLES = [
  {
    id: "welcome-to-blizzy-news",
    title: "Welcome to Blizzy News",
    category: "General",
    date: "2026-11-25",
    author: "Blizzy News Desk",
    excerpt: "A new home for clear, useful updates and stories that matter.",
    published: true,
    body: [
      "Welcome to Blizzy News, your destination for news, useful information and stories from Nigeria and around the world.",
      "Our goal is simple: to inform, educate and entertain with clear, accessible reporting. Check back regularly as new articles are added.",
      "Thank you for reading and being part of the Blizzy News community."
    ]
  },
  {
    id: "technology-shaping-tomorrow",
    title: "How technology continues to shape tomorrow",
    category: "Technology",
    date: "2026-11-24",
    author: "Blizzy News Desk",
    excerpt: "A look at the digital tools and ideas changing how people work, learn and connect.",
    published: true,
    body: [
      "Technology continues to influence everyday life, from communication and education to business and public services.",
      "As new tools become more accessible, digital skills and responsible use of technology are increasingly important.",
      "This is a sample article. Replace it with your own reporting before publishing."
    ]
  },
  {
    id: "business-and-small-enterprises",
    title: "Why small businesses matter to local communities",
    category: "Business",
    date: "2026-11-23",
    author: "Blizzy News Desk",
    excerpt: "Small enterprises can support jobs, services and fresh ideas in their communities.",
    published: true,
    body: [
      "Small businesses are an important part of many local economies. They provide goods and services, create jobs and help communities grow.",
      "Access to useful information, reliable infrastructure and business support can help entrepreneurs build stronger enterprises.",
      "This is a sample article. Replace it with verified information and your own reporting."
    ]
  }
];